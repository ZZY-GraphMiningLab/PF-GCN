from sklearn.metrics.pairwise import cosine_similarity
import torch
import numpy as np
import torch.nn as nn
import random



def new_uai(train_mask, labels, features):

    # 统计节点标签
    label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
    label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
    label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
    label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
    label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
    label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()
    label6_nodes = torch.nonzero(labels[train_mask] == 6).squeeze()
    label7_nodes = torch.nonzero(labels[train_mask] == 7).squeeze()
    label8_nodes = torch.nonzero(labels[train_mask] == 8).squeeze()
    label9_nodes = torch.nonzero(labels[train_mask] == 9).squeeze()
    label10_nodes = torch.nonzero(labels[train_mask] == 10).squeeze()
    label11_nodes = torch.nonzero(labels[train_mask] == 11).squeeze()
    label12_nodes = torch.nonzero(labels[train_mask] == 12).squeeze()
    label13_nodes = torch.nonzero(labels[train_mask] == 13).squeeze()
    label14_nodes = torch.nonzero(labels[train_mask] == 14).squeeze()
    label15_nodes = torch.nonzero(labels[train_mask] == 15).squeeze()
    label16_nodes = torch.nonzero(labels[train_mask] == 16).squeeze()
    label17_nodes = torch.nonzero(labels[train_mask] == 17).squeeze()
    label18_nodes = torch.nonzero(labels[train_mask] == 18).squeeze()
    # label6_nodes = torch.nonzero(labels[train_mask] == 6).squeeze()
    # 整合节点特征
    features0 = label0_nodes.cpu().numpy().tolist()
    features0_0 = features0.pop()
    features0_sum = MLP(features[features0_0].reshape(1, -1))
    for i in features0:
        features0_sum += MLP(features[i].reshape(1, -1))
    features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

    features1 = label1_nodes.cpu().numpy().tolist()
    features1_0 = features1.pop()
    features1_sum = MLP(features[features1_0].reshape(1, -1))
    for i in label1_nodes:
        features1_sum += MLP(features[i].reshape(1, -1))
    features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

    features2 = label2_nodes.cpu().numpy().tolist()
    features2_0 = features2.pop()
    features2_sum = MLP(features[features2_0].reshape(1, -1))
    for i in label2_nodes:
        features2_sum += MLP(features[i].reshape(1, -1))
    features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

    features3 = label3_nodes.cpu().numpy().tolist()
    features3_0 = features3.pop()
    features3_sum = MLP(features[features3_0].reshape(1, -1))
    for i in label3_nodes:
        features3_sum += MLP(features[i].reshape(1, -1))
    features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

    # features4 = label4_nodes.cpu().numpy().tolist()
    # features4_0 = features4.pop()
    # features4_sum = MLP(features[features4_0].reshape(1, -1))
    # for i in label4_nodes:
    #     features4_sum += MLP(features[i].reshape(1, -1))
    # features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

    features5 = label5_nodes.cpu().numpy().tolist()
    features5_0 = features5.pop()
    features5_sum = MLP(features[features5_0].reshape(1, -1))
    for i in label5_nodes:
        features5_sum += MLP(features[i].reshape(1, -1))
    features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)

    features6 = label6_nodes.cpu().numpy().tolist()
    features6_0 = features6.pop()
    features6_sum = MLP(features[features6_0].reshape(1, -1))
    for i in label6_nodes:
        features6_sum += MLP(features[i].reshape(1, -1))
    features6_sum = features6_sum.reshape(features6_sum.shape[0], -1)

    features7 = label7_nodes.cpu().numpy().tolist()
    features7_0 = features7.pop()
    features7_sum = MLP(features[features7_0].reshape(1, -1))
    for i in label7_nodes:
        features7_sum += MLP(features[i].reshape(1, -1))
    features7_sum = features7_sum.reshape(features7_sum.shape[0], -1)

    features8 = label8_nodes.cpu().numpy().tolist()
    features8_0 = features8.pop()
    features8_sum = MLP(features[features8_0].reshape(1, -1))
    for i in label8_nodes:
        features8_sum += MLP(features[i].reshape(1, -1))
    features8_sum = features8_sum.reshape(features8_sum.shape[0], -1)

    features9 = label9_nodes.cpu().numpy().tolist()
    features9_0 = features9.pop()
    features9_sum = MLP(features[features9_0].reshape(1, -1))
    for i in label9_nodes:
        features9_sum += MLP(features[i].reshape(1, -1))
    features9_sum = features9_sum.reshape(features9_sum.shape[0], -1)

    features10 = label10_nodes.cpu().numpy().tolist()
    features10_0 = features10.pop()
    features10_sum = MLP(features[features10_0].reshape(1, -1))
    for i in label10_nodes:
        features10_sum += MLP(features[i].reshape(1, -1))
    features10_sum = features10_sum.reshape(features10_sum.shape[0], -1)

    features11 = label11_nodes.cpu().numpy().tolist()
    features11_0 = features11.pop()
    features11_sum = MLP(features[features11_0].reshape(1, -1))
    for i in label11_nodes:
        features11_sum += MLP(features[i].reshape(1, -1))
    features11_sum = features11_sum.reshape(features11_sum.shape[0], -1)

    features12 = label12_nodes.cpu().numpy().tolist()
    features12_0 = features12.pop()
    features12_sum = MLP(features[features12_0].reshape(1, -1))
    for i in label12_nodes:
        features12_sum += MLP(features[i].reshape(1, -1))
    features12_sum = features12_sum.reshape(features12_sum.shape[0], -1)

    features13 = label13_nodes.cpu().numpy().tolist()
    features13_0 = features13.pop()
    features13_sum = MLP(features[features13_0].reshape(1, -1))
    for i in label13_nodes:
        features13_sum += MLP(features[i].reshape(1, -1))
    features13_sum = features13_sum.reshape(features13_sum.shape[0], -1)

    features14 = label14_nodes.cpu().numpy().tolist()
    features14_0 = features14.pop()
    features14_sum = MLP(features[features14_0].reshape(1, -1))
    for i in label14_nodes:
        features14_sum += MLP(features[i].reshape(1, -1))
    features14_sum = features14_sum.reshape(features14_sum.shape[0], -1)

    features15 = label15_nodes.cpu().numpy().tolist()
    features15_0 = features15.pop()
    features15_sum = MLP(features[features15_0].reshape(1, -1))
    for i in label15_nodes:
        features15_sum += MLP(features[i].reshape(1, -1))
    features15_sum = features15_sum.reshape(features15_sum.shape[0], -1)

    features16 = label16_nodes.cpu().numpy().tolist()
    features16_0 = features16.pop()
    features16_sum = MLP(features[features16_0].reshape(1, -1))
    for i in label16_nodes:
        features16_sum += MLP(features[i].reshape(1, -1))
    features16_sum = features16_sum.reshape(features16_sum.shape[0], -1)

    features17 = label17_nodes.cpu().numpy().tolist()
    features17_0 = features17.pop()
    features17_sum = MLP(features[features17_0].reshape(1, -1))
    for i in label17_nodes:
        features17_sum += MLP(features[i].reshape(1, -1))
    features17_sum = features17_sum.reshape(features17_sum.shape[0], -1)

    features18 = label18_nodes.cpu().numpy().tolist()
    features18_0 = features18.pop()
    features18_sum = MLP(features[features18_0].reshape(1, -1))
    for i in label18_nodes:
        features18_sum += MLP(features[i].reshape(1, -1))
    features18_sum = features18_sum.reshape(features18_sum.shape[0], -1)

    features0_sum = features0_sum / 20
    features1_sum = features1_sum / 20
    features2_sum = features2_sum / 20
    features3_sum = features3_sum / 20
    # features4_sum = features4_sum / 20
    features5_sum = features5_sum / 20
    features6_sum = features6_sum / 20
    features7_sum = features7_sum / 20
    features8_sum = features8_sum / 20
    features9_sum = features9_sum / 20
    features10_sum = features10_sum / 20
    features11_sum = features11_sum / 20
    features12_sum = features12_sum / 20
    features13_sum = features13_sum / 20
    features14_sum = features14_sum / 20
    features15_sum = features15_sum / 20
    features16_sum = features16_sum / 20
    features17_sum = features17_sum / 20
    features18_sum = features18_sum / 20



    new_trainmask = np.zeros(train_mask.shape[0], bool)
    new_trainmask = torch.tensor(new_trainmask)

    labels1 = np.copy(labels.cpu())
    labels1 = torch.tensor(labels1)
    count = 0
    # sample_list = [i for i in range(len(data))]
    sample_number = 80
    sample_list = random.sample(range(380, 3067), sample_number)
    for it in sample_list:
        ces_l = []
        s0 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features0_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s0.item())
        s1 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features1_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s1.item())
        s2 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features2_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s2.item())
        s3 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features3_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s3.item())
        # s4 = cosine_similarity(features[it].detach().reshape(1, -1), features4_sum.detach().reshape(1, -1))
        # ces_l.append(s4.item())
        s5 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features5_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s5.item())
        s6 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features6_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s6.item())
        s7 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features7_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s7.item())
        s8 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features8_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s8.item())
        s9 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features9_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s9.item())
        s10 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features10_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s10.item())
        s11 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features11_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s11.item())
        s12 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features12_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s12.item())
        s13 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features13_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s13.item())
        s14 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features14_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s14.item())
        s15 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features15_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s15.item())
        s16 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features16_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s16.item())
        s17 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features17_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s17.item())
        s18 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features18_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s18.item())


        # 先把预测的标签代替真实标签
        # 再改为true
        item = ces_l.index(max(ces_l))  # 预测的标签的序号
        # print(item)
        # 修改mask,和label

        new_trainmask[it] = True
        if labels1[it] == item:
            count += 1
            print(str(it) + str("yes"))

        labels1[it] = item
        # features[it]=features[it]*max(ces_l)+features[it]
    print(count)
    # print(label0_nodes)
    return train_mask, labels1