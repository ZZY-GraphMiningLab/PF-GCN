from sklearn.metrics.pairwise import cosine_similarity
import torch
import numpy as np
import torch.nn as nn
import random



def new_lab_node(train_mask, labels, features):
    MLP = nn.Sequential(
        nn.Linear(features.shape[1], features.shape[1]),
        nn.Sigmoid()
    )
    MLP=MLP.cuda()
    # 统计节点标签
    label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
    label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
    label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
    label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
    label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
    label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()
    # 整合节点特征
    features0 = label0_nodes.cpu().numpy().tolist()
    features0_0 = features0.pop()
    features0_sum = MLP(features[features0_0].reshape(1, -1))
    for i in features0:
        features0_sum += MLP(features[i].reshape(1, -1))
    features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

    features1 = label1_nodes.cpu().numpy().tolist()
    features1_0 = features1.pop()
    features1_sum = MLP(features[features1_0].reshape(1, -1))
    for i in label1_nodes:
        features1_sum += MLP(features[i].reshape(1, -1))
    features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

    features2 = label2_nodes.cpu().numpy().tolist()
    features2_0 = features2.pop()
    features2_sum = MLP(features[features2_0].reshape(1, -1))
    for i in label2_nodes:
        features2_sum += MLP(features[i].reshape(1, -1))
    features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

    features3 = label3_nodes.cpu().numpy().tolist()
    features3_0 = features3.pop()
    features3_sum = MLP(features[features3_0].reshape(1, -1))
    for i in label3_nodes:
        features3_sum += MLP(features[i].reshape(1, -1))
    features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

    features4 = label4_nodes.cpu().numpy().tolist()
    features4_0 = features4.pop()
    features4_sum = MLP(features[features4_0].reshape(1, -1))
    for i in label4_nodes:
        features4_sum += MLP(features[i].reshape(1, -1))
    features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

    features5 = label5_nodes.cpu().numpy().tolist()
    features5_0 = features5.pop()
    features5_sum = MLP(features[features5_0].reshape(1, -1))
    for i in label5_nodes:
        features5_sum += MLP(features[i].reshape(1, -1))
    features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)


    features0_sum = features0_sum / 20
    features1_sum = features1_sum / 20
    features2_sum = features2_sum / 20
    features3_sum = features3_sum / 20
    features4_sum = features4_sum / 20
    features5_sum = features5_sum / 20


    # new_trainmask = np.zeros(train_mask.shape[0], bool)
    # new_trainmask = torch.tensor(new_trainmask)

    labels1 = np.copy(labels.cpu())
    labels1 = torch.tensor(labels1)
    sample_number = 200
    sample_list = random.sample(range(120, 3327), sample_number)
    for it in sample_list:
        ces_l = []
        s0 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features0_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s0.item())
        s1 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features1_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s1.item())
        s2 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features2_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s2.item())
        s3 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features3_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s3.item())
        s4 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features4_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s4.item())
        s5 = cosine_similarity(features[it].cpu().detach().reshape(1, -1), features5_sum.cpu().detach().reshape(1, -1))
        ces_l.append(s5.item())

        item = ces_l.index(max(ces_l))  # 预测的标签的序号

        it=torch.tensor([it])
        it=it.cuda()
        # train_mask.tolist()
        train_mask=torch.cat((train_mask,it),0)
        labels1[it] = item

    return train_mask, labels1