from sklearn.metrics.pairwise import cosine_similarity
import torch
import numpy as np
import torch.nn as nn
import random



