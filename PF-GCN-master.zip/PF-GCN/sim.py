import numpy as np
import torch
import random
import scipy.sparse as sp
from sklearn.metrics.pairwise import cosine_similarity as cos

if __name__ == "__main__":
    l = np.loadtxt('../data/citeseer/citeseer.label', dtype=int)
    label = torch.LongTensor(np.array(l))
    print(label)
    l0=[]
    for i in range(3327):
        if label[i]==0:
            l0.append(i)

    l01=random.sample(l0, 10)
    print(l01)
    # [1276, 2111, 2957, 2745, 2263, 1891, 3250, 758, 1888, 1917]
    feature = np.load('../data/citeseer/feature.npz')
    print(feature)
    # features = sp.csr_matrix(feature)
    features = torch.FloatTensor(np.array(feature))

    print(features)
    for i in l01:
        feature1=features[i]
    print(feature1)

def jaccard(a,b):
    return len(set(a).intersection(set(b))) / len(set(a).union(set(b)))








