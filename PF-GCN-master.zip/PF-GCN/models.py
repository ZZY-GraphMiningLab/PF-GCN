import torch.nn as nn
import torch.nn.functional as F
from layers import GraphConvolution
from torch.nn.parameter import Parameter
import torch
import numpy as np
import math
import scipy.sparse as sp
from sklearn.metrics.pairwise import cosine_similarity as cos
import random
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, out, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, out)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training = self.training)
        x = self.gc2(x, adj)
        return x


class Attention(nn.Module):
    def __init__(self, in_size, hidden_size=16):
        super(Attention, self).__init__()

        self.project = nn.Sequential(
            nn.Linear(in_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        w = self.project(z)
        beta = torch.softmax(w, dim=1)
        return (beta * z).sum(1), beta

class SFGCN(nn.Module):
    def __init__(self, nfeat, nclass, nhid1, nhid2, n, dropout):
        super(SFGCN, self).__init__()

        self.SGCN1 = GCN(nfeat, nhid1, nhid2, dropout)
        self.SGCN2 = GCN(nfeat, nhid1, nhid2, dropout)
        self.CGCN = GCN(nfeat, nhid1, nhid2, dropout)

        self.dropout = dropout
        self.a = nn.Parameter(torch.zeros(size=(nhid2, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)
        self.attention = Attention(nhid2)
        self.tanh = nn.Tanh()
        self.nclass =nclass

        self.MLP = nn.Sequential(
            nn.Linear(nhid2, nclass),
            nn.LogSoftmax(dim=1)
        )
        self.Linear = nn.Sequential(
            nn.Linear(nfeat, nfeat),
        )
        self.Linear1 = nn.Sequential(
            nn.Linear(nfeat, nfeat),
        )
        self.MLP2 = nn.Sequential(
            nn.Linear(nfeat, nfeat),
            nn.Sigmoid()
        )


    # 特征方面，将原始特征输入，首先是捕获特征交叉信息，
    # 其次计算相似度，构图，问题是怎么选，KNN的k怎么自适应，
    # 生成的邻接矩阵作为特征视图

    def new_feat(self, feature):
        # 交叉特征
        feature01 = feature * self.Linear(feature)
        features = feature01 + feature
        # features=feature
        feature02 = feature * self.Linear(features)
        features = feature02 + features

        dist=cos(features.cpu().detach().numpy())
        topk=9
        inds = []
        for i in range(dist.shape[0]):
            ind = np.argpartition(dist[i, :], -(topk + 1))[-(topk + 1):]
            inds.append(ind)
        fname = '../data/tmp.txt'
        f = open(fname, 'w')
        for i, v in enumerate(inds):
            for vv in v:
                if vv == i:
                    pass
                else:
                    f.write('{} {}\n'.format(i, vv))
        f.close()

        f = open('../data/tmp.txt', 'r')
        # f2 = open('../data/' + dataset + '/knn/c' + str(topk) + '.txt', 'w')
        f2=[]
        lines = f.readlines()
        for line in lines:
            start, end = line.strip('\n').split(' ')
            if int(start) < int(end):
                f2.append('{} {}\n'.format(start, end))
        # f2.close()

        # 更新特征信息
        feature_edges = np.genfromtxt(f2, dtype=np.int32)
        fedges = np.array(list(feature_edges), dtype=np.int32).reshape(feature_edges.shape)
        fadj = sp.coo_matrix((np.ones(fedges.shape[0]), (fedges[:, 0], fedges[:, 1])), shape=(feature.shape[0],feature.shape[0]),
                             dtype=np.float32)
        fadj = fadj + fadj.T.multiply(fadj.T > fadj) - fadj.multiply(fadj.T > fadj)
        nfadj = self.normalize(fadj + sp.eye(fadj.shape[0]))

        nfadj = self.sparse_mx_to_torch_sparse_tensor(nfadj)

        return nfadj,features

    def plot_points(self,embedding):
        tsne = TSNE(n_components=2, init='pca', random_state=33)
        x_tsne = tsne.fit_transform(embedding)
        plt.figure(figsize=(10, 5))
        plt.subplot(121)
        plt.scatter(x_tsne[:, 0], x_tsne[:, 1], c=data.y)
        plt.xlabel('Visual')
        plt.show()
    def citeseer(self, sadj, train_mask, labels, features):

        # 统计节点标签
        label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
        label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
        label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
        label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
        label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
        label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()

        # 整合节点特征
        l0 = label0_nodes.cpu().numpy().tolist()
        degree0_sum=[]
        degree0_sum.append(np.sum(sadj[l0[-1]]))
        for i in label0_nodes:
            degree0_sum.append(np.sum(sadj[i]))

        l1 = label1_nodes.cpu().numpy().tolist()
        degree1_sum=[]
        degree1_sum.append(np.sum(sadj[l1[-1]]))
        for i in label1_nodes:
            degree1_sum.append(np.sum(sadj[i]))

        l2 = label2_nodes.cpu().numpy().tolist()
        degree2_sum =[]
        degree2_sum.append( np.sum(sadj[l2[-1]]))
        for i in label2_nodes:
            degree2_sum.append(np.sum(sadj[i]))

        l3 = label3_nodes.cpu().numpy().tolist()
        degree3_sum =[]
        degree3_sum.append( np.sum(sadj[l3[-1]]))
        for i in label3_nodes:
            degree3_sum.append(np.sum(sadj[i]))

        l4 = label4_nodes.cpu().numpy().tolist()
        degree4_sum =[]
        degree4_sum.append( np.sum(sadj[l4[-1]]))
        for i in label4_nodes:
            degree4_sum.append( np.sum(sadj[i]))

        l5 = label5_nodes.cpu().numpy().tolist()
        degree5_sum =[]
        degree5_sum.append( np.sum(sadj[l5[-1]]))
        for i in label5_nodes:
            degree5_sum.append(np.sum(sadj[i]))

        # 计算特征
        features0_sum = torch.tensor(np.zeros((1, 3703)))
        features1_sum = torch.tensor(np.zeros((1, 3703)))
        features2_sum = torch.tensor(np.zeros((1, 3703)))
        features3_sum = torch.tensor(np.zeros((1, 3703)))
        features4_sum = torch.tensor(np.zeros((1, 3703)))
        features5_sum = torch.tensor(np.zeros((1, 3703)))

        print(degree0_sum)
        print(degree1_sum)
        print(degree2_sum)
        print(degree3_sum)
        print(degree4_sum)
        print(degree5_sum)
        degree0_avg = sum(degree0_sum) / 20
        degree1_avg = sum(degree1_sum) / 20
        degree2_avg = sum(degree2_sum) / 20
        degree3_avg = sum(degree3_sum) / 20
        degree4_avg = sum(degree4_sum) / 20
        degree5_avg = sum(degree5_sum) / 20
        print(degree0_avg)
        print(degree1_avg)
        print(degree2_avg)
        print(degree3_avg)
        print(degree4_avg)
        print(degree5_avg)

        pl=0.75
        for i in label0_nodes:
            de = np.sum(sadj[i])
            if de < degree0_avg:
                features[i] = features[i] * pl
            # features[i] = features[i] * de/degree0_avg
            features0_sum += features[i].reshape(1, -1)
        features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

        for i in label1_nodes:
            de = np.sum(sadj[i])
            if de < degree1_avg:
                features[i] = features[i] * pl
            # features[i] = features[i] * de / degree1_avg
            features1_sum += features[i].reshape(1, -1)
        features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

        for i in label2_nodes:
            de = np.sum(sadj[i])
            if de < degree2_avg:
                features[i] = features[i] * pl
            features2_sum += features[i].reshape(1, -1)
        features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

        for i in label3_nodes:
            de = np.sum(sadj[i])
            if de < degree3_avg:
                features[i] = features[i] * pl
            features3_sum += features[i].reshape(1, -1)
        features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

        for i in label4_nodes:
            de = np.sum(sadj[i])
            if de < degree4_avg:
                features[i] = features[i] * pl
            features4_sum += features[i].reshape(1, -1)
        features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

        for i in label5_nodes:
            de = np.sum(sadj[i])
            if de < degree5_avg:
                features[i] = features[i] * pl
            features5_sum += features[i].reshape(1, -1)
        features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)

        features0_sum = features0_sum / 20
        features1_sum = features1_sum / 20
        features2_sum = features2_sum / 20
        features3_sum = features3_sum / 20
        features4_sum = features4_sum / 20
        features5_sum = features5_sum / 20

        # new_trainmask = np.zeros(train_mask.shape[0], bool)
        # new_trainmask = torch.tensor(new_trainmask)

        labels1 = np.copy(labels.cpu())
        labels1 = torch.tensor(labels1)
        # 20% citeseer 662  20% BlogCatalog 1039-5196  20% acm 605-3025
        # 33,166,333,666,1663,2329,2994
        sample_number = 2329
        sample_list = random.sample(range(120, 3327), sample_number)
        count = 0
        for it in sample_list:
            ces_l = []
            s0 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features0_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s0.item())
            s1 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features1_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s1.item())
            s2 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features2_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s2.item())
            s3 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features3_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s3.item())
            s4 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features4_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s4.item())
            s5 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features5_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s5.item())

            item = ces_l.index(max(ces_l))  # 预测的标签的序号

            it = torch.tensor([it])
            # it = it.cuda()

            train_mask = torch.cat((train_mask, it), 0)
            labels1[it] = item
        # 预测的正确的比例

            if labels[it]==labels1[it]:
                count+=1
        print(count/sample_number)

        return train_mask, labels1

    def flickr(self, sadj, train_mask, labels, features):
        # 统计节点标签
        label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
        label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
        label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
        label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
        label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
        label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()
        label6_nodes = torch.nonzero(labels[train_mask] == 6).squeeze()
        label7_nodes = torch.nonzero(labels[train_mask] == 7).squeeze()
        label8_nodes = torch.nonzero(labels[train_mask] == 8).squeeze()

        features0_sum = torch.tensor(np.zeros((1, 12047)))
        features1_sum = torch.tensor(np.zeros((1, 12047)))
        features2_sum = torch.tensor(np.zeros((1, 12047)))
        features3_sum = torch.tensor(np.zeros((1, 12047)))
        features4_sum = torch.tensor(np.zeros((1, 12047)))
        features5_sum = torch.tensor(np.zeros((1, 12047)))
        features6_sum = torch.tensor(np.zeros((1, 12047)))
        features7_sum = torch.tensor(np.zeros((1, 12047)))
        features8_sum = torch.tensor(np.zeros((1, 12047)))

        for i in label0_nodes:
            features0_sum += features[i].reshape(1, -1)
        features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

        for i in label1_nodes:
            features1_sum += features[i].reshape(1, -1)
        features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

        for i in label2_nodes:
            features2_sum += features[i].reshape(1, -1)
        features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

        for i in label3_nodes:
            features3_sum += features[i].reshape(1, -1)
        features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

        for i in label4_nodes:
            features4_sum += features[i].reshape(1, -1)
        features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

        for i in label5_nodes:
            features5_sum += features[i].reshape(1, -1)
        features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)

        for i in label6_nodes:
            features6_sum += features[i].reshape(1, -1)
        features6_sum = features6_sum.reshape(features6_sum.shape[0], -1)

        for i in label7_nodes:
            features7_sum += features[i].reshape(1, -1)
        features7_sum = features7_sum.reshape(features7_sum.shape[0], -1)

        for i in label8_nodes:
            features8_sum += features[i].reshape(1, -1)
        features8_sum = features8_sum.reshape(features8_sum.shape[0], -1)

        features0_sum = features0_sum / 20
        features1_sum = features1_sum / 20
        features2_sum = features2_sum / 20
        features3_sum = features3_sum / 20
        features4_sum = features4_sum / 20
        features5_sum = features5_sum / 20
        features6_sum = features6_sum / 20
        features7_sum = features7_sum / 20
        features8_sum = features8_sum / 20

        # new_trainmask = np.zeros(train_mask.shape[0], bool)
        # new_trainmask = torch.tensor(new_trainmask)

        labels1 = np.copy(labels.cpu())
        labels1 = torch.tensor(labels1)
        # 7575
        # 76,379,758,1515,3788,5303,6818
        sample_number = 3788
        sample_list = random.sample(range(180, 7575), sample_number)

        knowf = features[0:180, :]
        unknowf = features[180:, :]
        nodef = cos(unknowf, knowf)
        # 未标注节点与已标注节点特征相似度
        maxnode = nodef.argmax(axis=1)
        print(nodef)
        count = 0

        for it in sample_list:
            ces_l = []
            s0 = cos(features[it].cpu().detach().reshape(1, -1),
                     features0_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s0.item())
            s1 = cos(features[it].cpu().detach().reshape(1, -1),
                     features1_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s1.item())
            s2 = cos(features[it].cpu().detach().reshape(1, -1),
                     features2_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s2.item())
            s3 = cos(features[it].cpu().detach().reshape(1, -1),
                     features3_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s3.item())
            s4 = cos(features[it].cpu().detach().reshape(1, -1),
                     features4_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s4.item())
            s5 = cos(features[it].cpu().detach().reshape(1, -1),
                     features5_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s5.item())
            s6 = cos(features[it].cpu().detach().reshape(1, -1),
                     features6_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s6.item())
            s7 = cos(features[it].cpu().detach().reshape(1, -1),
                     features7_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s7.item())
            s8 = cos(features[it].cpu().detach().reshape(1, -1),
                     features8_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s8.item())

            item = ces_l.index(max(ces_l))  # 预测的标签的序号

            it = torch.tensor([it])
            # it = it.cuda()
            # 预测的正确的比例
            newit = it - 180
            itemnew = labels[maxnode[newit.item()]]
            if item == itemnew.item():
                labels1[it] = item
            else:
                pass

            train_mask = torch.cat((train_mask, it), 0)

            if labels[it] == labels1[it]:
                count += 1
        print(count)
        print(count / sample_number)

        return train_mask, labels1

    def cora(self, train_mask, labels, features):

        # 统计节点标签

        label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
        label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
        label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
        label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
        label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
        label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()
        label6_nodes = torch.nonzero(labels[train_mask] == 6).squeeze()
        label7_nodes = torch.nonzero(labels[train_mask] == 7).squeeze()
        label8_nodes = torch.nonzero(labels[train_mask] == 8).squeeze()
        label9_nodes = torch.nonzero(labels[train_mask] == 9).squeeze()
        label10_nodes = torch.nonzero(labels[train_mask] == 10).squeeze()
        label11_nodes = torch.nonzero(labels[train_mask] == 11).squeeze()
        label12_nodes = torch.nonzero(labels[train_mask] == 12).squeeze()
        label13_nodes = torch.nonzero(labels[train_mask] == 13).squeeze()
        label14_nodes = torch.nonzero(labels[train_mask] == 14).squeeze()
        label15_nodes = torch.nonzero(labels[train_mask] == 15).squeeze()
        label16_nodes = torch.nonzero(labels[train_mask] == 16).squeeze()
        label17_nodes = torch.nonzero(labels[train_mask] == 17).squeeze()
        label18_nodes = torch.nonzero(labels[train_mask] == 18).squeeze()
        label19_nodes = torch.nonzero(labels[train_mask] == 19).squeeze()
        label20_nodes = torch.nonzero(labels[train_mask] == 20).squeeze()
        label21_nodes = torch.nonzero(labels[train_mask] == 21).squeeze()
        label22_nodes = torch.nonzero(labels[train_mask] == 22).squeeze()
        label23_nodes = torch.nonzero(labels[train_mask] == 23).squeeze()
        label24_nodes = torch.nonzero(labels[train_mask] == 24).squeeze()
        label25_nodes = torch.nonzero(labels[train_mask] == 25).squeeze()
        label26_nodes = torch.nonzero(labels[train_mask] == 26).squeeze()
        label27_nodes = torch.nonzero(labels[train_mask] == 27).squeeze()
        label28_nodes = torch.nonzero(labels[train_mask] == 28).squeeze()
        label29_nodes = torch.nonzero(labels[train_mask] == 29).squeeze()
        label30_nodes = torch.nonzero(labels[train_mask] == 30).squeeze()
        label31_nodes = torch.nonzero(labels[train_mask] == 31).squeeze()
        label32_nodes = torch.nonzero(labels[train_mask] == 32).squeeze()
        label33_nodes = torch.nonzero(labels[train_mask] == 33).squeeze()
        label34_nodes = torch.nonzero(labels[train_mask] == 34).squeeze()
        label35_nodes = torch.nonzero(labels[train_mask] == 35).squeeze()
        label36_nodes = torch.nonzero(labels[train_mask] == 36).squeeze()
        label37_nodes = torch.nonzero(labels[train_mask] == 37).squeeze()
        label38_nodes = torch.nonzero(labels[train_mask] == 38).squeeze()
        label39_nodes = torch.nonzero(labels[train_mask] == 39).squeeze()
        label40_nodes = torch.nonzero(labels[train_mask] == 40).squeeze()
        label41_nodes = torch.nonzero(labels[train_mask] == 41).squeeze()
        label42_nodes = torch.nonzero(labels[train_mask] == 42).squeeze()
        label43_nodes = torch.nonzero(labels[train_mask] == 43).squeeze()
        label44_nodes = torch.nonzero(labels[train_mask] == 44).squeeze()
        label45_nodes = torch.nonzero(labels[train_mask] == 45).squeeze()
        label46_nodes = torch.nonzero(labels[train_mask] == 46).squeeze()
        label47_nodes = torch.nonzero(labels[train_mask] == 47).squeeze()
        label48_nodes = torch.nonzero(labels[train_mask] == 48).squeeze()
        label49_nodes = torch.nonzero(labels[train_mask] == 49).squeeze()
        label50_nodes = torch.nonzero(labels[train_mask] == 50).squeeze()
        label51_nodes = torch.nonzero(labels[train_mask] == 51).squeeze()
        label52_nodes = torch.nonzero(labels[train_mask] == 52).squeeze()
        label53_nodes = torch.nonzero(labels[train_mask] == 53).squeeze()
        label54_nodes = torch.nonzero(labels[train_mask] == 54).squeeze()
        label55_nodes = torch.nonzero(labels[train_mask] == 55).squeeze()
        label56_nodes = torch.nonzero(labels[train_mask] == 56).squeeze()
        label57_nodes = torch.nonzero(labels[train_mask] == 57).squeeze()
        label58_nodes = torch.nonzero(labels[train_mask] == 58).squeeze()
        label59_nodes = torch.nonzero(labels[train_mask] == 59).squeeze()
        label60_nodes = torch.nonzero(labels[train_mask] == 60).squeeze()
        label61_nodes = torch.nonzero(labels[train_mask] == 61).squeeze()
        label62_nodes = torch.nonzero(labels[train_mask] == 62).squeeze()
        label63_nodes = torch.nonzero(labels[train_mask] == 63).squeeze()
        label64_nodes = torch.nonzero(labels[train_mask] == 64).squeeze()
        label65_nodes = torch.nonzero(labels[train_mask] == 65).squeeze()
        label66_nodes = torch.nonzero(labels[train_mask] == 66).squeeze()
        label67_nodes = torch.nonzero(labels[train_mask] == 67).squeeze()
        label68_nodes = torch.nonzero(labels[train_mask] == 68).squeeze()
        label69_nodes = torch.nonzero(labels[train_mask] == 69).squeeze()


        # 整合节点特征
        features0 = label0_nodes.cpu().numpy().tolist()
        features0_0 = features0.pop()
        features0_sum = self.MLP2(features[features0_0].reshape(1, -1))
        for i in features0:
            features0_sum += self.MLP2(features[i].reshape(1, -1))
        features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

        features1 = label1_nodes.cpu().numpy().tolist()
        features1_0 = features1.pop()
        features1_sum = self.MLP2(features[features1_0].reshape(1, -1))
        for i in label1_nodes:
            features1_sum += self.MLP2(features[i].reshape(1, -1))
        features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

        features2 = label2_nodes.cpu().numpy().tolist()
        features2_0 = features2.pop()
        features2_sum = self.MLP2(features[features2_0].reshape(1, -1))
        for i in label2_nodes:
            features2_sum += self.MLP2(features[i].reshape(1, -1))
        features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

        features3 = label3_nodes.cpu().numpy().tolist()
        features3_0 = features3.pop()
        features3_sum = self.MLP2(features[features3_0].reshape(1, -1))
        for i in label3_nodes:
            features3_sum += self.MLP2(features[i].reshape(1, -1))
        features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

        features4 = label4_nodes.cpu().numpy().tolist()
        features4_0 = features4.pop()
        features4_sum = self.MLP2(features[features4_0].reshape(1, -1))
        for i in label4_nodes:
            features4_sum += self.MLP2(features[i].reshape(1, -1))
        features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

        features5 = label5_nodes.cpu().numpy().tolist()
        features5_0 = features5.pop()
        features5_sum = self.MLP2(features[features5_0].reshape(1, -1))
        for i in label5_nodes:
            features5_sum += self.MLP2(features[i].reshape(1, -1))
        features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)

        features6 = label6_nodes.cpu().numpy().tolist()
        features6_0 = features6.pop()
        features6_sum = self.MLP2(features[features6_0].reshape(1, -1))
        for i in label6_nodes:
            features6_sum += self.MLP2(features[i].reshape(1, -1))
        features6_sum = features6_sum.reshape(features6_sum.shape[0], -1)

        features7 = label7_nodes.cpu().numpy().tolist()
        features7_0 = features7.pop()
        features7_sum = self.MLP2(features[features7_0].reshape(1, -1))
        for i in label7_nodes:
            features7_sum += self.MLP2(features[i].reshape(1, -1))
        features7_sum = features7_sum.reshape(features7_sum.shape[0], -1)

        features8 = label8_nodes.cpu().numpy().tolist()
        features8_0 = features8.pop()
        features8_sum = self.MLP2(features[features8_0].reshape(1, -1))
        for i in label8_nodes:
            features8_sum += self.MLP2(features[i].reshape(1, -1))
        features8_sum = features8_sum.reshape(features8_sum.shape[0], -1)

        features9 = label9_nodes.cpu().numpy().tolist()
        features9_0 = features9.pop()
        features9_sum = self.MLP2(features[features9_0].reshape(1, -1))
        for i in label9_nodes:
            features9_sum += self.MLP2(features[i].reshape(1, -1))
        features9_sum = features9_sum.reshape(features9_sum.shape[0], -1)

        features10 = label10_nodes.cpu().numpy().tolist()
        features10_0 = features10.pop()
        features10_sum = self.MLP2(features[features10_0].reshape(1, -1))
        for i in label10_nodes:
            features10_sum += self.MLP2(features[i].reshape(1, -1))
        features10_sum = features10_sum.reshape(features10_sum.shape[0], -1)

        features11 = label11_nodes.cpu().numpy().tolist()
        features11_0 = features11.pop()
        features11_sum = self.MLP2(features[features11_0].reshape(1, -1))
        for i in label11_nodes:
            features11_sum += self.MLP2(features[i].reshape(1, -1))
        features11_sum = features11_sum.reshape(features11_sum.shape[0], -1)

        features12 = label12_nodes.cpu().numpy().tolist()
        features12_0 = features12.pop()
        features12_sum = self.MLP2(features[features12_0].reshape(1, -1))
        for i in label12_nodes:
            features12_sum += self.MLP2(features[i].reshape(1, -1))
        features12_sum = features12_sum.reshape(features12_sum.shape[0], -1)

        features13 = label13_nodes.cpu().numpy().tolist()
        features13_0 = features13.pop()
        features13_sum = self.MLP2(features[features13_0].reshape(1, -1))
        for i in label13_nodes:
            features13_sum += self.MLP2(features[i].reshape(1, -1))
        features13_sum = features13_sum.reshape(features13_sum.shape[0], -1)

        features14 = label14_nodes.cpu().numpy().tolist()
        features14_0 = features14.pop()
        features14_sum = self.MLP2(features[features14_0].reshape(1, -1))
        for i in label14_nodes:
            features14_sum += self.MLP2(features[i].reshape(1, -1))
        features14_sum = features14_sum.reshape(features14_sum.shape[0], -1)

        features15 = label15_nodes.cpu().numpy().tolist()
        features15_0 = features15.pop()
        features15_sum = self.MLP2(features[features15_0].reshape(1, -1))
        for i in label15_nodes:
            features15_sum += self.MLP2(features[i].reshape(1, -1))
        features15_sum = features15_sum.reshape(features15_sum.shape[0], -1)

        features16 = label16_nodes.cpu().numpy().tolist()
        features16_0 = features16.pop()
        features16_sum = self.MLP2(features[features16_0].reshape(1, -1))
        for i in label16_nodes:
            features16_sum += self.MLP2(features[i].reshape(1, -1))
        features16_sum = features16_sum.reshape(features16_sum.shape[0], -1)

        features17 = label17_nodes.cpu().numpy().tolist()
        features17_0 = features17.pop()
        features17_sum = self.MLP2(features[features17_0].reshape(1, -1))
        for i in label17_nodes:
            features17_sum += self.MLP2(features[i].reshape(1, -1))
        features17_sum = features17_sum.reshape(features17_sum.shape[0], -1)

        features18 = label18_nodes.cpu().numpy().tolist()
        features18_0 = features18.pop()
        features18_sum = self.MLP2(features[features18_0].reshape(1, -1))
        for i in label18_nodes:
            features18_sum += self.MLP2(features[i].reshape(1, -1))
        features18_sum = features18_sum.reshape(features18_sum.shape[0], -1)

        features19 = label19_nodes.cpu().numpy().tolist()
        features19_0 = features19.pop()
        features19_sum = self.MLP2(features[features19_0].reshape(1, -1))
        for i in label19_nodes:
            features19_sum += self.MLP2(features[i].reshape(1, -1))
        features19_sum = features19_sum.reshape(features19_sum.shape[0], -1)

        features20 = label20_nodes.cpu().numpy().tolist()
        features20_0 = features20.pop()
        features20_sum = self.MLP2(features[features20_0].reshape(1, -1))
        for i in label20_nodes:
            features20_sum += self.MLP2(features[i].reshape(1, -1))
        features20_sum = features20_sum.reshape(features20_sum.shape[0], -1)

        features21 = label21_nodes.cpu().numpy().tolist()
        features21_0 = features21.pop()
        features21_sum = self.MLP2(features[features21_0].reshape(1, -1))
        for i in label21_nodes:
            features21_sum += self.MLP2(features[i].reshape(1, -1))
        features21_sum = features21_sum.reshape(features21_sum.shape[0], -1)

        features22 = label22_nodes.cpu().numpy().tolist()
        features22_0 = features22.pop()
        features22_sum = self.MLP2(features[features22_0].reshape(1, -1))
        for i in label22_nodes:
            features22_sum += self.MLP2(features[i].reshape(1, -1))
        features22_sum = features22_sum.reshape(features22_sum.shape[0], -1)

        features23 = label23_nodes.cpu().numpy().tolist()
        features23_0 = features23.pop()
        features23_sum = self.MLP2(features[features23_0].reshape(1, -1))
        for i in label23_nodes:
            features23_sum += self.MLP2(features[i].reshape(1, -1))
        features23_sum = features23_sum.reshape(features23_sum.shape[0], -1)

        features24 = label24_nodes.cpu().numpy().tolist()
        features24_0 = features24.pop()
        features24_sum = self.MLP2(features[features24_0].reshape(1, -1))
        for i in label24_nodes:
            features24_sum += self.MLP2(features[i].reshape(1, -1))
        features24_sum = features24_sum.reshape(features24_sum.shape[0], -1)

        features25 = label25_nodes.cpu().numpy().tolist()
        features25_0 = features25.pop()
        features25_sum = self.MLP2(features[features25_0].reshape(1, -1))
        for i in label25_nodes:
            features25_sum += self.MLP2(features[i].reshape(1, -1))
        features25_sum = features25_sum.reshape(features25_sum.shape[0], -1)

        features26 = label26_nodes.cpu().numpy().tolist()
        features26_0 = features26.pop()
        features26_sum = self.MLP2(features[features26_0].reshape(1, -1))
        for i in label26_nodes:
            features26_sum += self.MLP2(features[i].reshape(1, -1))
        features26_sum = features26_sum.reshape(features26_sum.shape[0], -1)

        features27 = label27_nodes.cpu().numpy().tolist()
        features27_0 = features27.pop()
        features27_sum = self.MLP2(features[features27_0].reshape(1, -1))
        for i in label27_nodes:
            features27_sum += self.MLP2(features[i].reshape(1, -1))
        features27_sum = features27_sum.reshape(features27_sum.shape[0], -1)

        features28 = label28_nodes.cpu().numpy().tolist()
        features28_0 = features28.pop()
        features28_sum = self.MLP2(features[features28_0].reshape(1, -1))
        for i in label28_nodes:
            features28_sum += self.MLP2(features[i].reshape(1, -1))
        features28_sum = features28_sum.reshape(features28_sum.shape[0], -1)

        features29 = label29_nodes.cpu().numpy().tolist()
        features29_0 = features29.pop()
        features29_sum = self.MLP2(features[features29_0].reshape(1, -1))
        for i in label29_nodes:
            features29_sum += self.MLP2(features[i].reshape(1, -1))
        features29_sum = features29_sum.reshape(features29_sum.shape[0], -1)

        features30 = label30_nodes.cpu().numpy().tolist()
        features30_0 = features30.pop()
        features30_sum = self.MLP2(features[features30_0].reshape(1, -1))
        for i in features30:
            features30_sum += self.MLP2(features[i].reshape(1, -1))
        features30_sum = features30_sum.reshape(features30_sum.shape[0], -1)

        features31 = label31_nodes.cpu().numpy().tolist()
        features31_0 = features31.pop()
        features31_sum = self.MLP2(features[features31_0].reshape(1, -1))
        for i in label31_nodes:
            features31_sum += self.MLP2(features[i].reshape(1, -1))
        features31_sum = features31_sum.reshape(features31_sum.shape[0], -1)

        features32 = label32_nodes.cpu().numpy().tolist()
        features32_0 = features32.pop()
        features32_sum = self.MLP2(features[features32_0].reshape(1, -1))
        for i in label32_nodes:
            features32_sum += self.MLP2(features[i].reshape(1, -1))
        features32_sum = features32_sum.reshape(features32_sum.shape[0], -1)

        features33 = label33_nodes.cpu().numpy().tolist()
        features33_0 = features33.pop()
        features33_sum = self.MLP2(features[features33_0].reshape(1, -1))
        for i in label33_nodes:
            features33_sum += self.MLP2(features[i].reshape(1, -1))
        features33_sum = features33_sum.reshape(features33_sum.shape[0], -1)

        features34 = label34_nodes.cpu().numpy().tolist()
        features34_0 = features34.pop()
        features34_sum = self.MLP2(features[features34_0].reshape(1, -1))
        for i in label34_nodes:
            features34_sum += self.MLP2(features[i].reshape(1, -1))
        features34_sum = features34_sum.reshape(features34_sum.shape[0], -1)

        features35 = label35_nodes.cpu().numpy().tolist()
        features35_0 = features35.pop()
        features35_sum = self.MLP2(features[features35_0].reshape(1, -1))
        for i in label35_nodes:
            features35_sum += self.MLP2(features[i].reshape(1, -1))
        features35_sum = features35_sum.reshape(features35_sum.shape[0], -1)

        features36 = label36_nodes.cpu().numpy().tolist()
        features36_0 = features36.pop()
        features36_sum = self.MLP2(features[features36_0].reshape(1, -1))
        for i in label36_nodes:
            features36_sum += self.MLP2(features[i].reshape(1, -1))
        features36_sum = features36_sum.reshape(features36_sum.shape[0], -1)

        features37 = label37_nodes.cpu().numpy().tolist()
        features37_0 = features37.pop()
        features37_sum = self.MLP2(features[features37_0].reshape(1, -1))
        for i in label37_nodes:
            features37_sum += self.MLP2(features[i].reshape(1, -1))
        features37_sum = features37_sum.reshape(features37_sum.shape[0], -1)

        features38 = label38_nodes.cpu().numpy().tolist()
        features38_0 = features38.pop()
        features38_sum = self.MLP2(features[features38_0].reshape(1, -1))
        for i in label38_nodes:
            features38_sum += self.MLP2(features[i].reshape(1, -1))
        features38_sum = features38_sum.reshape(features38_sum.shape[0], -1)

        features39 = label39_nodes.cpu().numpy().tolist()
        features39_0 = features39.pop()
        features39_sum = self.MLP2(features[features39_0].reshape(1, -1))
        for i in label39_nodes:
            features39_sum += self.MLP2(features[i].reshape(1, -1))
        features39_sum = features39_sum.reshape(features39_sum.shape[0], -1)

        features40 = label40_nodes.cpu().numpy().tolist()
        features40_0 = features40.pop()
        features40_sum = self.MLP2(features[features40_0].reshape(1, -1))
        for i in features40:
            features40_sum += self.MLP2(features[i].reshape(1, -1))
        features40_sum = features40_sum.reshape(features40_sum.shape[0], -1)

        features41 = label41_nodes.cpu().numpy().tolist()
        features41_0 = features41.pop()
        features41_sum = self.MLP2(features[features41_0].reshape(1, -1))
        for i in label41_nodes:
            features41_sum += self.MLP2(features[i].reshape(1, -1))
        features41_sum = features41_sum.reshape(features41_sum.shape[0], -1)

        features42 = label42_nodes.cpu().numpy().tolist()
        features42_0 = features42.pop()
        features42_sum = self.MLP2(features[features42_0].reshape(1, -1))
        for i in label42_nodes:
            features42_sum += self.MLP2(features[i].reshape(1, -1))
        features42_sum = features42_sum.reshape(features42_sum.shape[0], -1)

        features43 = label43_nodes.cpu().numpy().tolist()
        features43_0 = features43.pop()
        features43_sum = self.MLP2(features[features43_0].reshape(1, -1))
        for i in label43_nodes:
            features43_sum += self.MLP2(features[i].reshape(1, -1))
        features43_sum = features43_sum.reshape(features43_sum.shape[0], -1)

        features44 = label44_nodes.cpu().numpy().tolist()
        features44_0 = features44.pop()
        features44_sum = self.MLP2(features[features44_0].reshape(1, -1))
        for i in label44_nodes:
            features44_sum += self.MLP2(features[i].reshape(1, -1))
        features44_sum = features44_sum.reshape(features44_sum.shape[0], -1)

        features55 = label55_nodes.cpu().numpy().tolist()
        features55_0 = features55.pop()
        features55_sum = self.MLP2(features[features55_0].reshape(1, -1))
        for i in label55_nodes:
            features55_sum += self.MLP2(features[i].reshape(1, -1))
        features55_sum = features55_sum.reshape(features55_sum.shape[0], -1)

        features56 = label56_nodes.cpu().numpy().tolist()
        features56_0 = features56.pop()
        features56_sum = self.MLP2(features[features56_0].reshape(1, -1))
        for i in label56_nodes:
            features56_sum += self.MLP2(features[i].reshape(1, -1))
        features56_sum = features56_sum.reshape(features56_sum.shape[0], -1)

        features57 = label57_nodes.cpu().numpy().tolist()
        features57_0 = features57.pop()
        features57_sum = self.MLP2(features[features57_0].reshape(1, -1))
        for i in label57_nodes:
            features57_sum += self.MLP2(features[i].reshape(1, -1))
        features57_sum = features57_sum.reshape(features57_sum.shape[0], -1)

        features58 = label58_nodes.cpu().numpy().tolist()
        features58_0 = features58.pop()
        features58_sum = self.MLP2(features[features58_0].reshape(1, -1))
        for i in label58_nodes:
            features58_sum += self.MLP2(features[i].reshape(1, -1))
        features58_sum = features58_sum.reshape(features58_sum.shape[0], -1)

        features59 = label59_nodes.cpu().numpy().tolist()
        features59_0 = features59.pop()
        features59_sum = self.MLP2(features[features59_0].reshape(1, -1))
        for i in label59_nodes:
            features59_sum += self.MLP2(features[i].reshape(1, -1))
        features59_sum = features59_sum.reshape(features59_sum.shape[0], -1)

        features60 = label60_nodes.cpu().numpy().tolist()
        features60_0 = features60.pop()
        features60_sum = self.MLP2(features[features60_0].reshape(1, -1))
        for i in features60:
            features60_sum += self.MLP2(features[i].reshape(1, -1))
        features60_sum = features60_sum.reshape(features60_sum.shape[0], -1)

        features61 = label61_nodes.cpu().numpy().tolist()
        features61_0 = features61.pop()
        features61_sum = self.MLP2(features[features61_0].reshape(1, -1))
        for i in label61_nodes:
            features61_sum += self.MLP2(features[i].reshape(1, -1))
        features61_sum = features61_sum.reshape(features61_sum.shape[0], -1)

        features62 = label62_nodes.cpu().numpy().tolist()
        features62_0 = features62.pop()
        features62_sum = self.MLP2(features[features62_0].reshape(1, -1))
        for i in label62_nodes:
            features62_sum += self.MLP2(features[i].reshape(1, -1))
        features62_sum = features62_sum.reshape(features62_sum.shape[0], -1)

        features63 = label63_nodes.cpu().numpy().tolist()
        features63_0 = features63.pop()
        features63_sum = self.MLP2(features[features63_0].reshape(1, -1))
        for i in label63_nodes:
            features63_sum += self.MLP2(features[i].reshape(1, -1))
        features63_sum = features63_sum.reshape(features63_sum.shape[0], -1)

        features64 = label64_nodes.cpu().numpy().tolist()
        features64_0 = features64.pop()
        features64_sum = self.MLP2(features[features64_0].reshape(1, -1))
        for i in label64_nodes:
            features64_sum += self.MLP2(features[i].reshape(1, -1))
        features64_sum = features64_sum.reshape(features64_sum.shape[0], -1)

        features65 = label65_nodes.cpu().numpy().tolist()
        features65_0 = features65.pop()
        features65_sum = self.MLP2(features[features65_0].reshape(1, -1))
        for i in label65_nodes:
            features65_sum += self.MLP2(features[i].reshape(1, -1))
        features65_sum = features65_sum.reshape(features65_sum.shape[0], -1)

        features66 = label66_nodes.cpu().numpy().tolist()
        features66_0 = features66.pop()
        features66_sum = self.MLP2(features[features66_0].reshape(1, -1))
        for i in label66_nodes:
            features66_sum += self.MLP2(features[i].reshape(1, -1))
        features66_sum = features66_sum.reshape(features66_sum.shape[0], -1)

        features67 = label67_nodes.cpu().numpy().tolist()
        features67_0 = features67.pop()
        features67_sum = self.MLP2(features[features67_0].reshape(1, -1))
        for i in label67_nodes:
            features67_sum += self.MLP2(features[i].reshape(1, -1))
        features67_sum = features67_sum.reshape(features67_sum.shape[0], -1)

        features68 = label68_nodes.cpu().numpy().tolist()
        features68_0 = features68.pop()
        features68_sum = self.MLP2(features[features68_0].reshape(1, -1))
        for i in label68_nodes:
            features68_sum += self.MLP2(features[i].reshape(1, -1))
        features68_sum = features68_sum.reshape(features68_sum.shape[0], -1)

        features69 = label69_nodes.cpu().numpy().tolist()
        features69_0 = features69.pop()
        features69_sum = self.MLP2(features[features69_0].reshape(1, -1))
        for i in label69_nodes:
            features69_sum += self.MLP2(features[i].reshape(1, -1))
        features69_sum = features69_sum.reshape(features69_sum.shape[0], -1)

        features50 = label50_nodes.cpu().numpy().tolist()
        features50_0 = features50.pop()
        features50_sum = self.MLP2(features[features50_0].reshape(1, -1))
        for i in features50:
            features50_sum += self.MLP2(features[i].reshape(1, -1))
        features50_sum = features50_sum.reshape(features50_sum.shape[0], -1)

        features51 = label51_nodes.cpu().numpy().tolist()
        features51_0 = features51.pop()
        features51_sum = self.MLP2(features[features51_0].reshape(1, -1))
        for i in label51_nodes:
            features51_sum += self.MLP2(features[i].reshape(1, -1))
        features51_sum = features51_sum.reshape(features51_sum.shape[0], -1)

        features52 = label52_nodes.cpu().numpy().tolist()
        features52_0 = features52.pop()
        features52_sum = self.MLP2(features[features52_0].reshape(1, -1))
        for i in label52_nodes:
            features52_sum += self.MLP2(features[i].reshape(1, -1))
        features52_sum = features52_sum.reshape(features52_sum.shape[0], -1)

        features53 = label53_nodes.cpu().numpy().tolist()
        features53_0 = features53.pop()
        features53_sum = self.MLP2(features[features53_0].reshape(1, -1))
        for i in label53_nodes:
            features53_sum += self.MLP2(features[i].reshape(1, -1))
        features53_sum = features53_sum.reshape(features53_sum.shape[0], -1)

        features54 = label54_nodes.cpu().numpy().tolist()
        features54_0 = features54.pop()
        features54_sum = self.MLP2(features[features54_0].reshape(1, -1))
        for i in label54_nodes:
            features54_sum += self.MLP2(features[i].reshape(1, -1))
        features54_sum = features54_sum.reshape(features54_sum.shape[0], -1)

        features45 = label45_nodes.cpu().numpy().tolist()
        features45_0 = features45.pop()
        features45_sum = self.MLP2(features[features45_0].reshape(1, -1))
        for i in label45_nodes:
            features45_sum += self.MLP2(features[i].reshape(1, -1))
        features45_sum = features45_sum.reshape(features45_sum.shape[0], -1)

        features46 = label46_nodes.cpu().numpy().tolist()
        features46_0 = features46.pop()
        features46_sum = self.MLP2(features[features46_0].reshape(1, -1))
        for i in label46_nodes:
            features46_sum += self.MLP2(features[i].reshape(1, -1))
        features46_sum = features46_sum.reshape(features46_sum.shape[0], -1)

        features47 = label47_nodes.cpu().numpy().tolist()
        features47_0 = features47.pop()
        features47_sum = self.MLP2(features[features47_0].reshape(1, -1))
        for i in label47_nodes:
            features47_sum += self.MLP2(features[i].reshape(1, -1))
        features47_sum = features47_sum.reshape(features47_sum.shape[0], -1)

        features48 = label48_nodes.cpu().numpy().tolist()
        features48_0 = features48.pop()
        features48_sum = self.MLP2(features[features48_0].reshape(1, -1))
        for i in label48_nodes:
            features48_sum += self.MLP2(features[i].reshape(1, -1))
        features48_sum = features48_sum.reshape(features48_sum.shape[0], -1)

        features49 = label49_nodes.cpu().numpy().tolist()
        features49_0 = features49.pop()
        features49_sum = self.MLP2(features[features49_0].reshape(1, -1))
        for i in label49_nodes:
            features49_sum += self.MLP2(features[i].reshape(1, -1))
        features49_sum = features49_sum.reshape(features49_sum.shape[0], -1)


        features0_sum = features0_sum / 20
        features1_sum = features1_sum / 20
        features2_sum = features2_sum / 20
        features3_sum = features3_sum / 20
        features4_sum = features4_sum / 20
        features5_sum = features5_sum / 20
        features6_sum = features6_sum / 20
        features7_sum = features7_sum / 20
        features8_sum = features8_sum / 20
        features9_sum = features9_sum / 20
        features10_sum = features10_sum / 20
        features11_sum = features11_sum / 20
        features12_sum = features12_sum / 20
        features13_sum = features13_sum / 20
        features14_sum = features14_sum / 20
        features15_sum = features15_sum / 20
        features16_sum = features16_sum / 20
        features17_sum = features17_sum / 20
        features18_sum = features18_sum / 20
        features19_sum = features19_sum / 20
        features20_sum = features20_sum / 20
        features21_sum = features21_sum / 20
        features22_sum = features22_sum / 20
        features23_sum = features23_sum / 20
        features24_sum = features24_sum / 20
        features25_sum = features25_sum / 20
        features26_sum = features26_sum / 20
        features27_sum = features27_sum / 20
        features28_sum = features28_sum / 20
        features29_sum = features29_sum / 20
        features30_sum = features30_sum / 20
        features31_sum = features31_sum / 20
        features32_sum = features32_sum / 20
        features33_sum = features33_sum / 20
        features34_sum = features34_sum / 20
        features35_sum = features35_sum / 20
        features36_sum = features36_sum / 20
        features37_sum = features37_sum / 20
        features38_sum = features38_sum / 20
        features39_sum = features39_sum / 20
        features40_sum = features40_sum / 20
        features41_sum = features41_sum / 20
        features42_sum = features42_sum / 20
        features43_sum = features43_sum / 20
        features44_sum = features44_sum / 20
        features45_sum = features45_sum / 20
        features46_sum = features46_sum / 20
        features47_sum = features47_sum / 20
        features48_sum = features48_sum / 20
        features49_sum = features49_sum / 20
        features50_sum = features50_sum / 20
        features51_sum = features51_sum / 20
        features52_sum = features52_sum / 20
        features53_sum = features53_sum / 20
        features54_sum = features54_sum / 20
        features55_sum = features55_sum / 20
        features56_sum = features56_sum / 20
        features57_sum = features57_sum / 20
        features58_sum = features58_sum / 20
        features59_sum = features59_sum / 20
        features60_sum = features60_sum / 20
        features61_sum = features61_sum / 20
        features62_sum = features62_sum / 20
        features63_sum = features63_sum / 20
        features64_sum = features64_sum / 20
        features65_sum = features65_sum / 20
        features66_sum = features66_sum / 20
        features67_sum = features67_sum / 20
        features68_sum = features68_sum / 20
        features69_sum = features69_sum / 20


        # new_trainmask = np.zeros(train_mask.shape[0], bool)
        # new_trainmask = torch.tensor(new_trainmask)

        labels1 = np.copy(labels.cpu())
        labels1 = torch.tensor(labels1)
        # 10 % 271 20% cora 542  20% BlogCatalog 1039-5196  20% acm 605-3025
        sample_number = 4355
        sample_list = random.sample(range(1400, 8710), sample_number)
        for it in sample_list:
            ces_l = []
            s0 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features0_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s0.item())
            s1 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features1_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s1.item())
            s2 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features2_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s2.item())
            s3 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features3_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s3.item())
            s4 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features4_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s4.item())
            s5 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features5_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s5.item())
            s6 = cos(features[it].cpu().detach().reshape(1, -1),
                     features6_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s6.item())

            s7 = cos(features[it].cpu().detach().reshape(1, -1),
                     features7_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s7.item())
            s8 = cos(features[it].cpu().detach().reshape(1, -1),
                     features8_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s8.item())
            s9 = cos(features[it].cpu().detach().reshape(1, -1),
                     features9_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s9.item())

            s10 = cos(features[it].cpu().detach().reshape(1, -1),
                     features10_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s10.item())
            s11 = cos(features[it].cpu().detach().reshape(1, -1),
                     features11_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s11.item())
            s12 = cos(features[it].cpu().detach().reshape(1, -1),
                     features12_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s12.item())
            s13 = cos(features[it].cpu().detach().reshape(1, -1),
                     features13_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s13.item())
            s14 = cos(features[it].cpu().detach().reshape(1, -1),
                     features14_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s14.item())
            s15 = cos(features[it].cpu().detach().reshape(1, -1),
                     features15_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s15.item())
            s16 = cos(features[it].cpu().detach().reshape(1, -1),
                     features16_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s16.item())

            s17 = cos(features[it].cpu().detach().reshape(1, -1),
                     features17_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s17.item())
            s18 = cos(features[it].cpu().detach().reshape(1, -1),
                     features18_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s18.item())
            s19 = cos(features[it].cpu().detach().reshape(1, -1),
                     features19_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s19.item())

            s20 = cos(features[it].cpu().detach().reshape(1, -1),
                     features20_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s20.item())
            s21 = cos(features[it].cpu().detach().reshape(1, -1),
                     features21_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s21.item())
            s22 = cos(features[it].cpu().detach().reshape(1, -1),
                     features22_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s22.item())
            s23 = cos(features[it].cpu().detach().reshape(1, -1),
                     features23_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s23.item())
            s24 = cos(features[it].cpu().detach().reshape(1, -1),
                     features24_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s24.item())
            s25 = cos(features[it].cpu().detach().reshape(1, -1),
                     features25_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s25.item())
            s26 = cos(features[it].cpu().detach().reshape(1, -1),
                     features26_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s26.item())

            s27 = cos(features[it].cpu().detach().reshape(1, -1),
                     features27_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s27.item())
            s28 = cos(features[it].cpu().detach().reshape(1, -1),
                     features28_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s28.item())
            s29 = cos(features[it].cpu().detach().reshape(1, -1),
                     features29_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s29.item())

            s30 = cos(features[it].cpu().detach().reshape(1, -1),
                     features30_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s30.item())
            s31 = cos(features[it].cpu().detach().reshape(1, -1),
                     features31_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s31.item())
            s32 = cos(features[it].cpu().detach().reshape(1, -1),
                     features32_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s32.item())
            s33 = cos(features[it].cpu().detach().reshape(1, -1),
                     features33_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s33.item())
            s34 = cos(features[it].cpu().detach().reshape(1, -1),
                     features34_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s34.item())
            s35 = cos(features[it].cpu().detach().reshape(1, -1),
                     features35_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s35.item())
            s36 = cos(features[it].cpu().detach().reshape(1, -1),
                     features36_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s36.item())

            s37 = cos(features[it].cpu().detach().reshape(1, -1),
                     features37_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s37.item())
            s38 = cos(features[it].cpu().detach().reshape(1, -1),
                     features38_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s38.item())
            s39 = cos(features[it].cpu().detach().reshape(1, -1),
                     features39_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s39.item())

            s40 = cos(features[it].cpu().detach().reshape(1, -1),
                     features40_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s40.item())
            s41 = cos(features[it].cpu().detach().reshape(1, -1),
                     features41_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s41.item())
            s42 = cos(features[it].cpu().detach().reshape(1, -1),
                     features42_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s42.item())
            s43 = cos(features[it].cpu().detach().reshape(1, -1),
                     features43_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s43.item())
            s44 = cos(features[it].cpu().detach().reshape(1, -1),
                     features44_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s44.item())
            s45 = cos(features[it].cpu().detach().reshape(1, -1),
                     features45_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s45.item())
            s46 = cos(features[it].cpu().detach().reshape(1, -1),
                     features46_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s46.item())

            s47 = cos(features[it].cpu().detach().reshape(1, -1),
                     features47_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s47.item())
            s48 = cos(features[it].cpu().detach().reshape(1, -1),
                     features48_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s48.item())
            s49 = cos(features[it].cpu().detach().reshape(1, -1),
                     features49_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s49.item())

            s50 = cos(features[it].cpu().detach().reshape(1, -1),
                     features50_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s50.item())
            s51 = cos(features[it].cpu().detach().reshape(1, -1),
                     features51_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s51.item())
            s52 = cos(features[it].cpu().detach().reshape(1, -1),
                     features52_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s52.item())
            s53 = cos(features[it].cpu().detach().reshape(1, -1),
                     features53_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s53.item())
            s54 = cos(features[it].cpu().detach().reshape(1, -1),
                     features54_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s54.item())
            s55 = cos(features[it].cpu().detach().reshape(1, -1),
                     features55_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s55.item())
            s56 = cos(features[it].cpu().detach().reshape(1, -1),
                     features56_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s56.item())

            s57 = cos(features[it].cpu().detach().reshape(1, -1),
                     features57_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s57.item())
            s58 = cos(features[it].cpu().detach().reshape(1, -1),
                     features58_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s58.item())
            s59 = cos(features[it].cpu().detach().reshape(1, -1),
                     features59_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s59.item())

            s60 = cos(features[it].cpu().detach().reshape(1, -1),
                     features60_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s60.item())
            s61 = cos(features[it].cpu().detach().reshape(1, -1),
                     features61_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s61.item())
            s62 = cos(features[it].cpu().detach().reshape(1, -1),
                     features62_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s62.item())
            s63 = cos(features[it].cpu().detach().reshape(1, -1),
                     features63_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s63.item())
            s64 = cos(features[it].cpu().detach().reshape(1, -1),
                     features64_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s64.item())
            s65 = cos(features[it].cpu().detach().reshape(1, -1),
                     features65_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s65.item())
            s66 = cos(features[it].cpu().detach().reshape(1, -1),
                     features66_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s66.item())

            s67 = cos(features[it].cpu().detach().reshape(1, -1),
                     features67_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s67.item())
            s68 = cos(features[it].cpu().detach().reshape(1, -1),
                     features68_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s68.item())
            s69 = cos(features[it].cpu().detach().reshape(1, -1),
                     features69_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s69.item())


            item = ces_l.index(max(ces_l))  # 预测的标签的序号

            it = torch.tensor([it])
            # it = it.cuda()
            # train_mask.tolist()
            train_mask = torch.cat((train_mask, it), 0)
            labels1[it] = item

        return train_mask, labels1
    def acm(self, sadj,train_mask, labels, features):

        # 统计节点标签
        label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
        label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
        label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
        # 整合节点特征
        degree0_sum = []
        for i in label0_nodes:
            degree0_sum.append(np.sum(sadj[i]))

        degree1_sum = []
        for i in label1_nodes:
            degree1_sum.append(np.sum(sadj[i]))

        degree2_sum = []
        for i in label2_nodes:
            degree2_sum.append(np.sum(sadj[i]))

        features0_sum = torch.tensor(np.zeros((1, 1870)))
        features1_sum = torch.tensor(np.zeros((1, 1870)))
        features2_sum = torch.tensor(np.zeros((1, 1870)))


        for i in label0_nodes:
            features0_sum += features[i].reshape(1, -1)
        features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

        for i in label1_nodes:
            features1_sum += features[i].reshape(1, -1)
        features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

        for i in label2_nodes:
            features2_sum += features[i].reshape(1, -1)
        features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

        features0_sum = features0_sum / 20
        features1_sum = features1_sum / 20
        features2_sum = features2_sum / 20

        count=0
        labels1 = np.copy(labels.cpu())
        labels1 = torch.tensor(labels1)
        # 30,151,303,605,1513,2118,2723
        sample_number = 1513
        sample_list = random.sample(range(60, 3025), sample_number)

        # 计算和哪个节点特征最相似
        knowf = features[0:60,:]
        unknowf = features[60:, :]
        nodef=cos(unknowf,knowf)
        # 未标注节点与已标注节点特征相似度
        maxnode=nodef.argmax(axis=1)
        # print(nodef)

        for it in sample_list:
            ces_l = []
            s0 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features0_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s0.item())

            s1 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features1_sum.cpu().detach().reshape(1, -1))

            ces_l.append(s1.item())

            s2 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features2_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s2.item())


            item = ces_l.index(max(ces_l))  # 预测的标签的序号

            it = torch.tensor([it])

            newit=it-60
            itemnew=labels[maxnode[newit.item()]]
            if item==itemnew.item():
                labels1[it] = item
            else:
                pass

            # 确定伪标签
            train_mask = torch.cat((train_mask, it), 0)

            if labels[it] == labels1[it]:
                count += 1
        print(count)
        print(count / sample_number)

        return train_mask, labels1
    def uai(self, train_mask, labels, features):

        # 统计节点标签
        label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
        label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
        label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
        label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
        label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
        label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()
        label6_nodes = torch.nonzero(labels[train_mask] == 6).squeeze()
        label7_nodes = torch.nonzero(labels[train_mask] == 7).squeeze()
        label8_nodes = torch.nonzero(labels[train_mask] == 8).squeeze()
        label9_nodes = torch.nonzero(labels[train_mask] == 9).squeeze()
        label10_nodes = torch.nonzero(labels[train_mask] == 10).squeeze()
        label11_nodes = torch.nonzero(labels[train_mask] == 11).squeeze()
        label12_nodes = torch.nonzero(labels[train_mask] == 12).squeeze()
        label13_nodes = torch.nonzero(labels[train_mask] == 13).squeeze()
        label14_nodes = torch.nonzero(labels[train_mask] == 14).squeeze()
        label15_nodes = torch.nonzero(labels[train_mask] == 15).squeeze()
        label16_nodes = torch.nonzero(labels[train_mask] == 16).squeeze()
        label17_nodes = torch.nonzero(labels[train_mask] == 17).squeeze()
        label18_nodes = torch.nonzero(labels[train_mask] == 18).squeeze()
        # label6_nodes = torch.nonzero(labels[train_mask] == 6).squeeze()
        # 整合节点特征
        features0 = label0_nodes.cpu().numpy().tolist()
        features0_0 = features0.pop()
        features0_sum = self.MLP2(features[features0_0].reshape(1, -1))
        for i in features0:
            features0_sum += self.MLP2(features[i].reshape(1, -1))
        features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

        features1 = label1_nodes.cpu().numpy().tolist()
        features1_0 = features1.pop()
        features1_sum = self.MLP2(features[features1_0].reshape(1, -1))
        for i in label1_nodes:
            features1_sum += self.MLP2(features[i].reshape(1, -1))
        features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

        features2 = label2_nodes.cpu().numpy().tolist()
        features2_0 = features2.pop()
        features2_sum = self.MLP2(features[features2_0].reshape(1, -1))
        for i in label2_nodes:
            features2_sum += self.MLP2(features[i].reshape(1, -1))
        features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

        features3 = label3_nodes.cpu().numpy().tolist()
        features3_0 = features3.pop()
        features3_sum = self.MLP2(features[features3_0].reshape(1, -1))
        for i in label3_nodes:
            features3_sum += self.MLP2(features[i].reshape(1, -1))
        features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

        # features4 = label4_nodes.cpu().numpy().tolist()
        # features4_0 = features4.pop()
        # features4_sum = self.MLP2(features[features4_0].reshape(1, -1))
        # for i in label4_nodes:
        #     features4_sum += self.MLP2(features[i].reshape(1, -1))
        # features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

        features5 = label5_nodes.cpu().numpy().tolist()
        features5_0 = features5.pop()
        features5_sum = self.MLP2(features[features5_0].reshape(1, -1))
        for i in label5_nodes:
            features5_sum += self.MLP2(features[i].reshape(1, -1))
        features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)

        features6 = label6_nodes.cpu().numpy().tolist()
        features6_0 = features6.pop()
        features6_sum = self.MLP2(features[features6_0].reshape(1, -1))
        for i in label6_nodes:
            features6_sum += self.MLP2(features[i].reshape(1, -1))
        features6_sum = features6_sum.reshape(features6_sum.shape[0], -1)

        features7 = label7_nodes.cpu().numpy().tolist()
        features7_0 = features7.pop()
        features7_sum = self.MLP2(features[features7_0].reshape(1, -1))
        for i in label7_nodes:
            features7_sum += self.MLP2(features[i].reshape(1, -1))
        features7_sum = features7_sum.reshape(features7_sum.shape[0], -1)

        features8 = label8_nodes.cpu().numpy().tolist()
        features8_0 = features8.pop()
        features8_sum = self.MLP2(features[features8_0].reshape(1, -1))
        for i in label8_nodes:
            features8_sum += self.MLP2(features[i].reshape(1, -1))
        features8_sum = features8_sum.reshape(features8_sum.shape[0], -1)

        features9 = label9_nodes.cpu().numpy().tolist()
        features9_0 = features9.pop()
        features9_sum = self.MLP2(features[features9_0].reshape(1, -1))
        for i in label9_nodes:
            features9_sum += self.MLP2(features[i].reshape(1, -1))
        features9_sum = features9_sum.reshape(features9_sum.shape[0], -1)

        features10 = label10_nodes.cpu().numpy().tolist()
        features10_0 = features10.pop()
        features10_sum = self.MLP2(features[features10_0].reshape(1, -1))
        for i in label10_nodes:
            features10_sum += self.MLP2(features[i].reshape(1, -1))
        features10_sum = features10_sum.reshape(features10_sum.shape[0], -1)

        features11 = label11_nodes.cpu().numpy().tolist()
        features11_0 = features11.pop()
        features11_sum = self.MLP2(features[features11_0].reshape(1, -1))
        for i in label11_nodes:
            features11_sum += self.MLP2(features[i].reshape(1, -1))
        features11_sum = features11_sum.reshape(features11_sum.shape[0], -1)

        features12 = label12_nodes.cpu().numpy().tolist()
        features12_0 = features12.pop()
        features12_sum = self.MLP2(features[features12_0].reshape(1, -1))
        for i in label12_nodes:
            features12_sum += self.MLP2(features[i].reshape(1, -1))
        features12_sum = features12_sum.reshape(features12_sum.shape[0], -1)

        features13 = label13_nodes.cpu().numpy().tolist()
        features13_0 = features13.pop()
        features13_sum = self.MLP2(features[features13_0].reshape(1, -1))
        for i in label13_nodes:
            features13_sum += self.MLP2(features[i].reshape(1, -1))
        features13_sum = features13_sum.reshape(features13_sum.shape[0], -1)

        features14 = label14_nodes.cpu().numpy().tolist()
        features14_0 = features14.pop()
        features14_sum = self.MLP2(features[features14_0].reshape(1, -1))
        for i in label14_nodes:
            features14_sum += self.MLP2(features[i].reshape(1, -1))
        features14_sum = features14_sum.reshape(features14_sum.shape[0], -1)

        features15 = label15_nodes.cpu().numpy().tolist()
        features15_0 = features15.pop()
        features15_sum = self.MLP2(features[features15_0].reshape(1, -1))
        for i in label15_nodes:
            features15_sum += self.MLP2(features[i].reshape(1, -1))
        features15_sum = features15_sum.reshape(features15_sum.shape[0], -1)

        features16 = label16_nodes.cpu().numpy().tolist()
        features16_0 = features16.pop()
        features16_sum = self.MLP2(features[features16_0].reshape(1, -1))
        for i in label16_nodes:
            features16_sum += self.MLP2(features[i].reshape(1, -1))
        features16_sum = features16_sum.reshape(features16_sum.shape[0], -1)

        features17 = label17_nodes.cpu().numpy().tolist()
        features17_0 = features17.pop()
        features17_sum = self.MLP2(features[features17_0].reshape(1, -1))
        for i in label17_nodes:
            features17_sum += self.MLP2(features[i].reshape(1, -1))
        features17_sum = features17_sum.reshape(features17_sum.shape[0], -1)

        features18 = label18_nodes.cpu().numpy().tolist()
        features18_0 = features18.pop()
        features18_sum = self.MLP2(features[features18_0].reshape(1, -1))
        for i in label18_nodes:
            features18_sum += self.MLP2(features[i].reshape(1, -1))
        features18_sum = features18_sum.reshape(features18_sum.shape[0], -1)

        features0_sum = features0_sum / 20
        features1_sum = features1_sum / 20
        features2_sum = features2_sum / 20
        features3_sum = features3_sum / 20
        # features4_sum = features4_sum / 20
        features5_sum = features5_sum / 20
        features6_sum = features6_sum / 20
        features7_sum = features7_sum / 20
        features8_sum = features8_sum / 20
        features9_sum = features9_sum / 20
        features10_sum = features10_sum / 20
        features11_sum = features11_sum / 20
        features12_sum = features12_sum / 20
        features13_sum = features13_sum / 20
        features14_sum = features14_sum / 20
        features15_sum = features15_sum / 20
        features16_sum = features16_sum / 20
        features17_sum = features17_sum / 20
        features18_sum = features18_sum / 20

        # new_trainmask = np.zeros(train_mask.shape[0], bool)
        # new_trainmask = torch.tensor(new_trainmask)

        labels1 = np.copy(labels.cpu())
        labels1 = torch.tensor(labels1)
        count = 0
        # sample_list = [i for i in range(len(data))]
        # uai-3067-613
        # 31, 155, 307, 614,1534
        sample_number = 1534
        sample_list = random.sample(range(180, 3067), sample_number)
        for it in sample_list:
            ces_l = []
            s0 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features0_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s0.item())
            s1 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features1_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s1.item())
            s2 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features2_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s2.item())
            s3 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features3_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s3.item())
            # s4 = cos(features[it].detach().reshape(1, -1), features4_sum.detach().reshape(1, -1))
            # ces_l.append(s4.item())
            s5 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features5_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s5.item())
            s6 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features6_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s6.item())
            s7 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features7_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s7.item())
            s8 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features8_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s8.item())
            s9 = cos(features[it].cpu().detach().reshape(1, -1),
                                   features9_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s9.item())
            s10 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features10_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s10.item())
            s11 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features11_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s11.item())
            s12 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features12_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s12.item())
            s13 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features13_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s13.item())
            s14 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features14_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s14.item())
            s15 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features15_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s15.item())
            s16 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features16_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s16.item())
            s17 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features17_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s17.item())
            s18 = cos(features[it].cpu().detach().reshape(1, -1),
                                    features18_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s18.item())

            item = ces_l.index(max(ces_l))  # 预测的标签的序号

            it = torch.tensor([it])
            # it = it.cuda()

            train_mask = torch.cat((train_mask, it), 0)
            labels1[it] = item
        return train_mask, labels1
    def BlogCatalog(self,sadj, train_mask, labels, features):
        # 统计节点标签
        label0_nodes = torch.nonzero(labels[train_mask] == 0).squeeze()
        label1_nodes = torch.nonzero(labels[train_mask] == 1).squeeze()
        label2_nodes = torch.nonzero(labels[train_mask] == 2).squeeze()
        label3_nodes = torch.nonzero(labels[train_mask] == 3).squeeze()
        label4_nodes = torch.nonzero(labels[train_mask] == 4).squeeze()
        label5_nodes = torch.nonzero(labels[train_mask] == 5).squeeze()

        # 计算特征
        features0_sum = torch.tensor(np.zeros((1, 8189)))
        features1_sum = torch.tensor(np.zeros((1, 8189)))
        features2_sum = torch.tensor(np.zeros((1, 8189)))
        features3_sum = torch.tensor(np.zeros((1, 8189)))
        features4_sum = torch.tensor(np.zeros((1, 8189)))
        features5_sum = torch.tensor(np.zeros((1, 8189)))


        for i in label0_nodes:
            features0_sum += features[i].reshape(1, -1)
        features0_sum = features0_sum.reshape(features0_sum.shape[0], -1)

        for i in label1_nodes:
            features1_sum += features[i].reshape(1, -1)
        features1_sum = features1_sum.reshape(features1_sum.shape[0], -1)

        for i in label2_nodes:
            features2_sum += features[i].reshape(1, -1)
        features2_sum = features2_sum.reshape(features2_sum.shape[0], -1)

        for i in label3_nodes:
            features3_sum += features[i].reshape(1, -1)
        features3_sum = features3_sum.reshape(features3_sum.shape[0], -1)

        for i in label4_nodes:
            features4_sum += features[i].reshape(1, -1)
        features4_sum = features4_sum.reshape(features4_sum.shape[0], -1)

        for i in label5_nodes:
            features5_sum += features[i].reshape(1, -1)
        features5_sum = features5_sum.reshape(features5_sum.shape[0], -1)

        features0_sum = features0_sum / 20
        features1_sum = features1_sum / 20
        features2_sum = features2_sum / 20
        features3_sum = features3_sum / 20
        features4_sum = features4_sum / 20
        features5_sum = features5_sum / 20

        # new_trainmask = np.zeros(train_mask.shape[0], bool)
        # new_trainmask = torch.tensor(new_trainmask)

        labels1 = np.copy(labels.cpu())
        labels1 = torch.tensor(labels1)

        count = 0
        # 52,260,520,1039,2598,3637,4767
        sample_number = 2598
        sample_list = random.sample(range(120, 5196), sample_number)

        knowf = features[0:120, :]
        unknowf = features[120:, :]
        nodef = cos(unknowf, knowf)
        # 未标注节点与已标注节点特征相似度
        maxnode = nodef.argmax(axis=1)
        print(nodef)

        for it in sample_list:
            ces_l = []
            s0 = cos(features[it].cpu().detach().reshape(1, -1),
                     features0_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s0.item())
            s1 = cos(features[it].cpu().detach().reshape(1, -1),
                     features1_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s1.item())
            s2 = cos(features[it].cpu().detach().reshape(1, -1),
                     features2_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s2.item())
            s3 = cos(features[it].cpu().detach().reshape(1, -1),
                     features3_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s3.item())
            s4 = cos(features[it].cpu().detach().reshape(1, -1),
                     features4_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s4.item())
            s5 = cos(features[it].cpu().detach().reshape(1, -1),
                     features5_sum.cpu().detach().reshape(1, -1))
            ces_l.append(s5.item())

            item = ces_l.index(max(ces_l))  # 预测的标签的序号

            it = torch.tensor([it])
            # it = it.cuda()
            # 预测的正确的比例
            newit = it - 120
            itemnew = labels[maxnode[newit.item()]]
            if item == itemnew.item():
                labels1[it] = item
            else:
                pass

            train_mask = torch.cat((train_mask, it), 0)

            if labels[it] == labels1[it]:
                count += 1
        print(count)
        print(count / sample_number)

        return train_mask, labels1
    def forward(self,x, sadj, fadj):

        emb1 = self.SGCN1(x, sadj) # Special_GCN out1 -- sadj structure graph
        com1 = self.CGCN(x, sadj)  # Common_GCN out1 -- sadj structure graph
        com2 = self.CGCN(x, fadj)  # Common_GCN out2 -- fadj feature graph
        emb2 = self.SGCN1(x, fadj) # Special_GCN out2 -- fadj feature graph
        Xcom = (com1 + com2) / 2

        # cemb,_=model1.embed(x,fadj,True,None)
        ##attention
        # emb = torch.stack([emb1, emb2, Xcom], dim=1)
        # cemb=np.squeeze(cemb, 0)
        emb = torch.stack([emb1, emb2], dim=1)
        emb, att = self.attention(emb)
        output = self.MLP(emb)
        # self.plot_points(output.detach().numpy())
        return output, att, emb1, emb2, emb

    def sparse_mx_to_torch_sparse_tensor(self,sparse_mx):
        """Convert a scipy sparse matrix to a torch sparse tensor."""
        sparse_mx = sparse_mx.tocoo().astype(np.float32)
        indices = torch.from_numpy(np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
        values = torch.from_numpy(sparse_mx.data)
        shape = torch.Size(sparse_mx.shape)
        return torch.sparse.FloatTensor(indices, values, shape)

    def normalize(self,mx):
        """Row-normalize sparse matrix"""
        rowsum = np.array(mx.sum(1))
        r_inv = np.power(rowsum, -1).flatten()
        r_inv[np.isinf(r_inv)] = 0.
        r_mat_inv = sp.diags(r_inv)
        mx = r_mat_inv.dot(mx)
        return mx


